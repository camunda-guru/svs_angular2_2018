export class Policy
{
    constructor(public policyNo:string,public amountInsured:number)
    {

    }
}