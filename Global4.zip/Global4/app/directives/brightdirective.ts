import{Directive,ElementRef} from "@angular/core";
@Directive({
    selector:'[bright]'
})
export class BrightDirective{
    constructor(private e1:ElementRef)
    {
        /*
        if(e1.nativeElement.nodeName==='div')
        {
            e1.nativeElement.className='h1style';
        }
        */

        if(e1.nativeElement.nodeName==='H1')
        {
            console.log("heading hitting....");
            e1.nativeElement.nodeName.style.backgroundColor='lightblue';
        }

    }

}