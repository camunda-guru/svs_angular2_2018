import {Injectable} from "@angular/core";
import{Policy} from "../models/policy";


@Injectable()
export class PolicyService {
    getPolicies() {
        return [
            new Policy("234/456/614/674",4385834),
            new Policy("234/456/614/675",100000),
            new Policy("234/456/614/676",1285834),
            new Policy("234/456/614/677",3245834),
            new Policy("234/456/614/678",50000),
            new Policy("234/456/614/679",35000),
        ];
    }
}