claimApp.controller('ClaimController',['$scope',function($scope)
{
    $scope.vehicleObj={
        regnNo:"",
        model:"",
        engineNo:""
    }
    $scope.policyHolderObj={
        aadharCardNo:0,
        firstName:"",
        lastName:"",
        mobileNo:0
    }
    $scope.policyObj={
        policyNo:0,
        vehicle:$scope.vehicleObj,
        policyHolder:$scope.policyHolderObj
    }

    $scope.claimObj={
        policyNo:0,
        claimId:0,
        claimDate:new Date()
    }

    $scope.claimSubmit=function()
    {
          console.log($scope.claimObj);
          console.log($scope.policyObj);
    }

}])