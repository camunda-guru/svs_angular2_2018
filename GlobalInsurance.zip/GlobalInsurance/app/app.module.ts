import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";
import {AppComponent} from "./app.component";
import {MenuComponent} from "./menu/menu.component";
import {MenuService} from "./services/menuservice";
import {AppRoutingModule} from "./app.routing.module";
import {ClaimComponent} from "./claim/claim.component";
import {ClaimApprovalComponent} from "./claim/claim.claimapprovalcomponent";
import {PaymentComponent} from "./payment/payment.component";
import {AssessorComponent} from "./assessor/assessor.component";
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {JsonpModule} from "@angular/http";
import {CityService} from "./services/cityservice";
import {HttpModule} from "@angular/http";
import {DataService} from "./services/dataservice";
@NgModule({
    imports:[BrowserModule,CommonModule,AppRoutingModule,HttpModule,FormsModule,ReactiveFormsModule,JsonpModule],
    declarations:[AppComponent,MenuComponent,ClaimComponent,ClaimApprovalComponent,PaymentComponent,AssessorComponent],
    providers:[MenuService,CityService,DataService],
    bootstrap:[AppComponent]
})

export class AppModule
{

}