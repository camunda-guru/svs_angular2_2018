import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";
import {AppComponent} from "./app.component";
import {MenuComponent} from "./menu/menu.component";
import {MenuService} from "./services/menuservice";

@NgModule({
    imports:[BrowserModule,CommonModule],
    declarations:[AppComponent,MenuComponent],
    providers:[MenuService],
    bootstrap:[AppComponent]
})

export class AppModule
{

}