import {Component} from "@angular/core";


@Component({
        selector:'gic-home',
        template:`<img src="{{imgPath}}">`,
        styleUrls:['./app/app.component.css']



})
export class AppComponent
{
  private imgPath:string;

  constructor()
  {
      this.imgPath="./images/gic.jpg";
  }


}